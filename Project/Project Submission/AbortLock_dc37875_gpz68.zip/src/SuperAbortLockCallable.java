public class SuperAbortLockCallable {
    public int tester = 0;
    private int testee = 0;

    public int getTestee() {
        return testee;
    }

    public void setTestee(int testee) {
        this.testee = testee;
    }
}
