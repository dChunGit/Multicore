public interface Lock {
    void lock();
    void unlock();
}
