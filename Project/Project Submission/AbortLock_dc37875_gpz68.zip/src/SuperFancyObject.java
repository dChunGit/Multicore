public class SuperFancyObject {
    boolean testSuper = false;

    public String toString() {
        return testSuper + "";
    }
}
